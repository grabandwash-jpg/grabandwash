"use client";
export default function Page() {
  return <div>Hello Grab&Wash Website - Deploy Ready</div>;
}
